mv rondb_bin_use rondb-${RONDB_VERSION}-linux-glibc2.17-x86_64
tar cfz rondb-${RONDB_VERSION}-linux-glibc2.17-x86_64.tar.gz rondb-${RONDB_VERSION}-linux-glibc2.17-x86_64
rm -rf rondb-${RONDB_VERSION}-linux-glibc2.17-x86_64
mv -f rondb-${RONDB_VERSION}-linux-glibc2.17-x86_64.tar.gz /data/.
